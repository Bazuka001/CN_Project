#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>

#define SERVER_IP "127.0.0.1"
#define TCP_PORT 8080
#define UDP_PORT 8081
#define MAX_MSG 512

char CAMPUS[50];
char DEPT[50] = "HEAD";
int sock;
char inbox[MAX_MSG][512];
int inboxCount=0;
pthread_mutex_t inboxLock = PTHREAD_MUTEX_INITIALIZER;

void addInbox(const char *msg){
    pthread_mutex_lock(&inboxLock);
    if(inboxCount<MAX_MSG) strncpy(inbox[inboxCount++], msg,511);
    pthread_mutex_unlock(&inboxLock);
}

void viewInbox(){
    pthread_mutex_lock(&inboxLock);
    if(inboxCount==0) printf("Inbox empty\n");
    else for(int i=0;i<inboxCount;i++) printf("%d) %s\n",i+1,inbox[i]);
    pthread_mutex_unlock(&inboxLock);
}

void *receiver(void *arg){
    char buf[1024];
    while(1){
        int n = recv(sock, buf,sizeof(buf)-1,0);
        if(n<=0){ printf("Disconnected from server\n"); exit(0);}
        buf[n]=0;
        printf("\n[NEW MESSAGE] %s\n",buf);
        addInbox(buf);
    }
}

void *udpHeartbeat(void *arg){
    int udpSock = socket(AF_INET, SOCK_DGRAM,0);
    struct sockaddr_in servAddr;
    servAddr.sin_family = AF_INET;
    servAddr.sin_port = htons(UDP_PORT);
    servAddr.sin_addr.s_addr = inet_addr(SERVER_IP);

    char buf[200];
    while(1){
        snprintf(buf, sizeof(buf), "HEARTBEAT %s-%s", CAMPUS, DEPT);
        sendto(udpSock, buf, strlen(buf), 0, (struct sockaddr*)&servAddr, sizeof(servAddr));
        sleep(10);
    }
}

void menu(){
    printf("\n--- MENU ---\n");
    printf("1) Send Message\n");
    printf("2) View Inbox\n");
    printf("3) Exit\nChoice: ");
}

int main(int argc, char *argv[]){
    if(argc<2){ printf("Usage: ./c <Campus> [Dept]\n"); return 0;}
    strncpy(CAMPUS,argv[1],49);
    if(argc>=3) strncpy(DEPT,argv[2],49);

    sock = socket(AF_INET, SOCK_STREAM,0);
    struct sockaddr_in serv;
    serv.sin_family = AF_INET;
    serv.sin_port = htons(TCP_PORT);
    serv.sin_addr.s_addr = inet_addr(SERVER_IP);

    if(connect(sock,(struct sockaddr*)&serv,sizeof(serv))<0){ printf("Cannot connect to server\n"); return 0;}
    char auth[100]; snprintf(auth,sizeof(auth),"%s %s",CAMPUS,DEPT);
    send(sock,auth,strlen(auth),0);
    printf("[%s-%s] Connected to server\n",CAMPUS,DEPT);

    pthread_t tid, hbTid;
    pthread_create(&tid,NULL,receiver,NULL);
    pthread_create(&hbTid,NULL,udpHeartbeat,NULL);

    while(1){
        menu();
        int ch;
        if(scanf("%d",&ch)!=1){ 
            printf("Invalid input! Enter 1-3.\n"); 
            while(getchar()!='\n'); 
            continue;
        }
        char msg[512], tCampus[50], tDept[50]; getchar();
        switch(ch){
            case 1:
                int type;
                printf("1) Campus\n2) Department\nEnter: ");
                if(scanf("%d",&type)!=1 || (type!=1 && type!=2)){ printf("Invalid choice!\n"); while(getchar()!='\n'); continue;}
                getchar();
                printf("Target Campus: "); scanf("%s",tCampus); getchar();
                if(type==2){ printf("Target Dept: "); scanf("%s",tDept); getchar();}
                else strcpy(tDept,"ALL");
                printf("Message: "); fgets(msg,sizeof(msg),stdin); msg[strcspn(msg,"\n")] = 0;
                char full[1024]; snprintf(full,sizeof(full),"SRC:%s-%s|DST:%s-%s|MSG:%s",CAMPUS,DEPT,tCampus,tDept,msg);
                send(sock,full,strlen(full),0);
                break;
            case 2: viewInbox(); break;
            case 3: close(sock); exit(0); break;
            default: printf("Invalid choice! Enter 1-3.\n"); break;
        }
    }
}

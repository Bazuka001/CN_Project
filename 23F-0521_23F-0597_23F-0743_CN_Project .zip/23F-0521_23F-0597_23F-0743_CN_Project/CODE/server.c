#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <time.h>

#define TCP_PORT 8080
#define UDP_PORT 8081
#define MAX_CLIENTS 100
#define MAX_MSG 512

typedef struct {
    int sock;
    char campus[50];
    char dept[50];
    int online;
} clientNode;

typedef struct {
    char campus[50];
    char dept[50];
    char lastSeen[50];
} heartbeatNode;

clientNode clients[MAX_CLIENTS];
heartbeatNode heartbeats[MAX_CLIENTS];
int clientCount = 0, hbCount = 0;
pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t hbLock = PTHREAD_MUTEX_INITIALIZER;

// CLIENT MANAGEMENT
void addClient(int sock, const char *campus, const char *dept){
    pthread_mutex_lock(&lock);
    if(clientCount < MAX_CLIENTS){
        clients[clientCount].sock = sock;
        strncpy(clients[clientCount].campus, campus,49);
        strncpy(clients[clientCount].dept, dept,49);
        clients[clientCount].online = 1;
        clientCount++;
    }
    pthread_mutex_unlock(&lock);
}

void removeClient(int sock){
    pthread_mutex_lock(&lock);
    for(int i=0;i<clientCount;i++){
        if(clients[i].sock==sock){
            clients[i].online=0;
            close(clients[i].sock);
            printf("[DISCONNECTED] %s-%s\n",clients[i].campus, clients[i].dept);
            break;
        }
    }
    pthread_mutex_unlock(&lock);
}

// TCP BROADCAST
void sendTCP(int sock, const char *msg){
    if(send(sock,msg,strlen(msg),0)<=0){
        removeClient(sock);
    }
}

void broadcastAll(const char *msg){
    pthread_mutex_lock(&lock);
    for(int i=0;i<clientCount;i++)
        if(clients[i].online) sendTCP(clients[i].sock,msg);
    pthread_mutex_unlock(&lock);
}

void broadcastCampus(const char *campus, const char *msg){
    pthread_mutex_lock(&lock);
    for(int i=0;i<clientCount;i++)
        if(clients[i].online && strcmp(clients[i].campus,campus)==0)
            sendTCP(clients[i].sock,msg);
    pthread_mutex_unlock(&lock);
}

void broadcastDept(const char *campus, const char *dept, const char *msg){
    pthread_mutex_lock(&lock);
    for(int i=0;i<clientCount;i++)
        if(clients[i].online && strcmp(clients[i].campus,campus)==0 &&
           (strcmp(dept,"ALL")==0 || strcmp(clients[i].dept,dept)==0))
            sendTCP(clients[i].sock,msg);
    pthread_mutex_unlock(&lock);
}

// VIEW FUNCTIONS
void viewStatus(){
    pthread_mutex_lock(&lock);
    printf("\n--- CLIENT STATUS ---\n");
    for(int i=0;i<clientCount;i++)
        printf("%s-%s : %s\n", clients[i].campus, clients[i].dept, 
               clients[i].online?"ONLINE":"OFFLINE");
    pthread_mutex_unlock(&lock);
}

void viewHeartbeats(){
    pthread_mutex_lock(&hbLock);
    printf("\n--- HEARTBEATS ---\n");
    for(int i=0;i<hbCount;i++)
        printf("%s-%s : last seen %s\n",heartbeats[i].campus, heartbeats[i].dept, heartbeats[i].lastSeen);
    pthread_mutex_unlock(&hbLock);
}

// CLIENT HANDLER THREAD
void *clientHandler(void *arg){
    int sock = *(int*)arg;
    char buf[MAX_MSG];
    char campus[50], dept[50];

    memset(buf,0,sizeof(buf));
    recv(sock, buf, sizeof(buf)-1,0);
    sscanf(buf,"%s %s", campus, dept);
    if(strlen(dept)==0) strcpy(dept,"HEAD");

    addClient(sock,campus,dept);
    printf("[CONNECTED] %s-%s\n",campus,dept);

    while(1){
        memset(buf,0,sizeof(buf));
        int n = recv(sock, buf, sizeof(buf)-1,0);
        if(n<=0){ removeClient(sock); break; }
        buf[n]=0;

        char srcCampus[50], srcDept[50], tgtCampus[50], tgtDept[50], message[512];
        sscanf(buf,"SRC:%[^-]-%[^|]|DST:%[^-]-%[^|]|MSG:%[^\n]", srcCampus, srcDept, tgtCampus, tgtDept, message);

        char out[1024];
        snprintf(out,sizeof(out),"[%s-%s] %s", srcCampus, srcDept, message);

        if(strcmp(tgtDept,"ALL")==0)
            broadcastCampus(tgtCampus,out);
        else
            broadcastDept(tgtCampus,tgtDept,out);
    }
    return NULL;
}

// UDP HEARTBEAT LISTENER
void *udpListener(void *arg){
    int udpSock = socket(AF_INET, SOCK_DGRAM,0);
    struct sockaddr_in servAddr, cliAddr;
    socklen_t len = sizeof(cliAddr);
    servAddr.sin_family = AF_INET;
    servAddr.sin_port = htons(UDP_PORT);
    servAddr.sin_addr.s_addr = INADDR_ANY;

    bind(udpSock,(struct sockaddr*)&servAddr,sizeof(servAddr));
    char buf[200];

    while(1){
        int n = recvfrom(udpSock, buf, sizeof(buf)-1,0,(struct sockaddr*)&cliAddr,&len);
        if(n>0){
            buf[n]=0;
            char campus[50], dept[50];
            if(sscanf(buf,"HEARTBEAT %[^-]-%s",campus,dept)==2){
                pthread_mutex_lock(&hbLock);
                int found=0;
                for(int i=0;i<hbCount;i++){
                    if(strcmp(heartbeats[i].campus,campus)==0 && strcmp(heartbeats[i].dept,dept)==0){
                        snprintf(heartbeats[i].lastSeen,sizeof(heartbeats[i].lastSeen),"%s",ctime(&(time_t){time(NULL)}));
                        found=1; break;
                    }
                }
                if(!found && hbCount<MAX_CLIENTS){
                    strncpy(heartbeats[hbCount].campus,campus,49);
                    strncpy(heartbeats[hbCount].dept,dept,49);
                    snprintf(heartbeats[hbCount].lastSeen,sizeof(heartbeats[hbCount].lastSeen),"%s",ctime(&(time_t){time(NULL)}));
                    hbCount++;
                }
                pthread_mutex_unlock(&hbLock);
            }
        }
    }
}

// SERVER MENU THREAD
void *serverMenuThread(void *arg){
    while(1){
        printf("\n--- SERVER MENU ---\n");
        printf("1) Broadcast to All Campuses\n");
        printf("2) Broadcast to Campus\n");
        printf("3) Broadcast to Campus Department\n");
        printf("4) View Client Status\n");
        printf("5) View Heartbeats\n");
        printf("6) Exit\nChoice: ");

        int op;
        if(scanf("%d",&op)!=1){ 
            printf("Invalid input! Please enter a number 1-6.\n");
            while(getchar()!='\n'); // clear input
            continue;
        }
        char msg[512], campus[50], dept[50]; getchar();
        switch(op){
            case 1: printf("Message: "); fgets(msg,sizeof(msg),stdin); msg[strcspn(msg,"\n")]=0; broadcastAll(msg); break;
            case 2: printf("Campus: "); scanf("%s",campus); getchar(); printf("Message: "); fgets(msg,sizeof(msg),stdin); msg[strcspn(msg,"\n")]=0; broadcastCampus(campus,msg); break;
            case 3: printf("Campus: "); scanf("%s",campus); printf("Department: "); scanf("%s",dept); getchar(); printf("Message: "); fgets(msg,sizeof(msg),stdin); msg[strcspn(msg,"\n")]=0; broadcastDept(campus,dept,msg); break;
            case 4: viewStatus(); break;
            case 5: viewHeartbeats(); break;
            case 6: exit(0);
            default: printf("Invalid option! Choose 1-6.\n"); break;
        }
    }
}

int main(){
    int serverSock = socket(AF_INET, SOCK_STREAM,0);
    struct sockaddr_in servAddr, cliAddr;
    socklen_t cliSize = sizeof(cliAddr);
    servAddr.sin_family = AF_INET;
    servAddr.sin_port = htons(TCP_PORT);
    servAddr.sin_addr.s_addr = INADDR_ANY;

    bind(serverSock,(struct sockaddr*)&servAddr,sizeof(servAddr));
    listen(serverSock,10);
    printf("[SERVER STARTED]\n");

    pthread_t udpTid, menuTid;
    pthread_create(&udpTid,NULL,udpListener,NULL);
    pthread_create(&menuTid,NULL,serverMenuThread,NULL);

    while(1){
        int newSock = accept(serverSock,(struct sockaddr*)&cliAddr,&cliSize);
        pthread_t tid;
        pthread_create(&tid,NULL,clientHandler,&newSock);
    }
}
